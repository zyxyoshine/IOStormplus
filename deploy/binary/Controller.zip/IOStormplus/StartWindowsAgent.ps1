﻿$User = "vmadmin"
$PWord = ConvertTo-SecureString –String "!!!!1234abcd" –AsPlainText -Force
$Credential = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $User, $PWord
$cname = $args[0]
$ser1=New-PSSession -ComputerName $cname -Credential $Credential
$ControllerIP = foreach($ip in (ipconfig) -like '*IPv4*') { ($ip -split ' : ')[-1]} 
invoke-command -session $ser1 -scriptblock {
    $Root = "C:\IOStormplus\"
    $ControllerIP = $using:ControllerIP
    $VMname = hostname
    $VMSize = Get-Content ($Root + 'vmsize.txt')
    $VMIp = foreach($ip in (ipconfig) -like '*IPv4*') { ($ip -split ' : ')[-1]} 
    $username = 'vmadmin'
    $password = '!!!!1234abcd'
    $agentName = "agent.exe"
    $agentPath = $Root + $agentName
    $args = ' ' + $ControllerIP + ' ' + $VMname + ' ' + $VMIp + ' ' + $VMSize
    $action = New-ScheduledTaskAction -Execute $agentPath -Argument $args -WorkingDirectory $Root
    $trigger = @()
    $trigger += New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1)
    $trigger += New-ScheduledTaskTrigger -AtStartup
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RunOnlyIfNetworkAvailable -DontStopOnIdleEnd -Priority 4
    Unregister-ScheduledTask -TaskName "VMIOSTORM" -Confirm:0 -ErrorAction Ignore
    Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "VMIOSTORM" -Description "VM iostorm agent" -User $username -Password $password -RunLevel Highest -Settings $settings
}